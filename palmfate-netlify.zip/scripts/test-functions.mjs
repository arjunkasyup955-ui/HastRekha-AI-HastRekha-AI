/**
 * Netlify functions ka offline test — OpenRouter ko nakli (mock) bana kar.
 * Chalane ke liye:  node scripts/test-functions.mjs
 * Isse asli API key kharch nahi hoti.
 */
import assert from 'node:assert';

const realFetch = globalThis.fetch;
let lastRequest = null;

function mockOpenRouter(content) {
  globalThis.fetch = async (url, opts) => {
    lastRequest = { url, body: JSON.parse(opts.body), headers: opts.headers };
    return new Response(
      JSON.stringify({ model: 'mock/model', choices: [{ message: { content } }] }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  };
}

const post = (body) =>
  new Request('http://localhost/api/x', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

const TINY_PNG =
  'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

const READING_JSON = JSON.stringify({
  is_palm: true,
  summary: 'A hopeful season ahead.',
  summary_hi: 'आगे शुभ समय है।',
  overall_fortune: 'Auspicious',
  overall_fortune_hi: 'शुभ',
  heart_line: 'Deep and curved.',
  heart_line_hi: 'गहरी और मुड़ी हुई।',
  life_line: 'Strong.',
  life_line_hi: 'मज़बूत।',
  head_line: 'Straight.',
  head_line_hi: 'सीधी।',
  destiny_line: 'Clear.',
  destiny_line_hi: 'स्पष्ट।',
  love_rating: 812,      // jaan-boojh kar galat — clamp hona chahiye
  career_rating: 77,
  health_rating: 81,
  wealth_rating: 69,
  lucky_number: 7
});

let passed = 0;
const ok = (name) => {
  passed++;
  console.log('  ✓ ' + name);
};

console.log('\nanalyzePalm');
{
  const { default: analyzePalm } = await import('../netlify/functions/analyzePalm.mjs');

  // 1. API key nahi
  delete process.env.OPENROUTER_API_KEY;
  let res = await analyzePalm(post({ image_url: TINY_PNG }));
  assert.equal(res.status, 500);
  assert.match((await res.json()).error, /OPENROUTER_API_KEY/);
  ok('key na hone par saaf error');

  process.env.OPENROUTER_API_KEY = 'sk-or-test';
  process.env.OPENROUTER_MODEL = 'test/model';

  // 2. GET mana hai
  res = await analyzePalm(new Request('http://localhost/api/x'));
  assert.equal(res.status, 405);
  ok('sirf POST chalta hai');

  // 3. image ke bina
  res = await analyzePalm(post({}));
  assert.equal(res.status, 400);
  ok('bina image ke 400');

  // 4. sahi reading (markdown fence ke saath bhi parse ho)
  mockOpenRouter('```json\n' + READING_JSON + '\n```');
  res = await analyzePalm(post({ image_url: TINY_PNG }));
  assert.equal(res.status, 200);
  const { reading } = await res.json();
  assert.equal(reading.love_rating, 100, 'clamp 0-100');
  assert.equal(reading.summary_hi, 'आगे शुभ समय है।');
  assert.equal(reading.lucky_number, 7);
  ok('reading parse + normalize (```json fence bhi chalta hai)');

  // 5. request me image aur model theek gaya
  assert.equal(lastRequest.body.model, 'test/model');
  const content = lastRequest.body.messages[1].content;
  assert.equal(content[1].image_url.url, TINY_PNG);
  assert.equal(lastRequest.body.response_format.type, 'json_object');
  ok('OpenRouter ko sahi payload gaya');

  // 6. hatheli nahi hai
  mockOpenRouter(JSON.stringify({ is_palm: false }));
  res = await analyzePalm(post({ image_url: TINY_PNG }));
  assert.equal(res.status, 422);
  ok('galat photo par 422 + samajhne layak message');

  // 7. bahut badi image
  res = await analyzePalm(post({ image_url: 'data:image/png;base64,' + 'A'.repeat(7_000_000) }));
  assert.equal(res.status, 400);
  ok('bahut badi image reject');
}

console.log('\nchatWithPalmist');
{
  const { default: chat } = await import('../netlify/functions/chatWithPalmist.mjs');
  mockOpenRouter('Namaste beta! Aapki rekha shubh hai.');

  const res = await chat(
    post({
      messages: [
        { role: 'assistant', content: 'Namaste' },
        { role: 'user', content: 'Mera naam Anuj hai' },
        { role: 'assistant', content: 'Shubh' },
        { role: 'user', content: 'Career kaisa rahega?' }
      ],
      image_url: TINY_PNG,
      reading_context: 'Summary: hopeful',
      lang: 'hi'
    })
  );
  assert.equal(res.status, 200);
  assert.equal((await res.json()).reply, 'Namaste beta! Aapki rekha shubh hai.');
  ok('reply wapas aaya');

  const msgs = lastRequest.body.messages;
  assert.equal(msgs[0].role, 'system');
  assert.match(msgs[0].content, /Guruji AI/);
  assert.match(msgs[0].content, /HINDI/);
  assert.match(msgs[0].content, /Summary: hopeful/);
  ok('Guruji skill prompt + bhasha + reading context system me gaya');

  const withImage = msgs.filter((m) => Array.isArray(m.content));
  assert.equal(withImage.length, 1, 'photo sirf ek baar');
  ok('hatheli ka photo sirf pehle user turn me (token bachat)');

  const bad = await chat(post({ messages: [] }));
  assert.equal(bad.status, 400);
  ok('khaali messages par 400');
}

globalThis.fetch = realFetch;
console.log(`\n✅ ${passed} tests passed\n`);
