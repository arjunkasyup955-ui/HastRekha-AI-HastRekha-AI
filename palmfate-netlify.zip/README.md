# PalmFate — AI हस्तरेखा ऐप (Netlify + OpenRouter)

यह वही ऐप है जो पहले **Base44** पर बना था, अब पूरी तरह **Netlify** पर चलने के लिए तैयार।
Base44 का SDK, login, database और AI — चारों हटा दिए गए हैं। AI अब **OpenRouter** से आता है।

---

## 1. सबसे तेज़ तरीका — ZIP से deploy (कोई terminal नहीं)

1. इस फोल्डर का ZIP बनाइए (जो आपको मिला है वही है)।
2. https://app.netlify.com पर जाइए → **Add new site → Deploy manually**।
   ⚠️ यहाँ ZIP को सीधे मत खींचिए — Netlify को build करना है, इसलिए बेहतर तरीका नीचे वाला (GitHub) है।

**सुझाया हुआ तरीका (GitHub):**

1. इस फोल्डर को अपने GitHub repo में डालिए (push कीजिए)।
2. Netlify → **Add new site → Import an existing project → GitHub** → अपना repo चुनिए।
3. Build settings अपने आप भर जाएँगी (`netlify.toml` से):
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Functions directory: `netlify/functions`
4. **Deploy site** दबाइए।

## 2. OpenRouter की API key डालिए (यह ज़रूरी है)

Netlify → आपकी site → **Site configuration → Environment variables → Add a variable**:

| Key | Value |
| --- | --- |
| `OPENROUTER_API_KEY` | आपकी key (https://openrouter.ai/keys से) |
| `OPENROUTER_MODEL` | *(वैकल्पिक)* जैसे `google/gemini-2.5-flash` |
| `OPENROUTER_SITE_URL` | *(वैकल्पिक)* आपकी site का URL |
| `OPENROUTER_APP_NAME` | *(वैकल्पिक)* `PalmFate` |

key डालने के बाद **Deploys → Trigger deploy → Deploy site** ज़रूर दबाएँ (env variable पुराने deploy पर लागू नहीं होता)।

> मॉडल vision वाला होना चाहिए (फोटो देख सके)। default `google/gemini-2.5-flash` सस्ता + तेज़ है।
> बदलना हो तो सिर्फ़ `OPENROUTER_MODEL` बदलिए, code छूने की ज़रूरत नहीं।

## 3. जाँच कीजिए

- `https://आपकी-site.netlify.app/api/health` खोलिए →
  `{"ok":true,"openrouter_key_set":true,"model":"…"}` दिखना चाहिए।
- `openrouter_key_set: false` आए तो key सही से सेव नहीं हुई या redeploy नहीं हुआ।

---

## Guruji की image बदलना

`public/` फोल्डर में अपनी दो images डालिए:

```
public/guruji-bg.png       ← chat का background (जो zodiac wheel आपने भेजा)
public/guruji-avatar.png   ← Guruji का गोल फ़ोटो
```

फिर `src/lib/assets.js` में `.svg` को `.png` कर दीजिए — बस इतना ही।
अभी placeholder SVG लगे हैं ताकि ऐप कहीं टूटा हुआ न दिखे।

## Guruji का prompt बदलना

पूरा astrologer skill prompt यहाँ है: **`netlify/shared/guruji-prompt.mjs`**
(पहले यह Base44 के settings में छिपा था — अब आपके code में है, जब चाहें बदलिए।)

---

## Local पर चलाना

```bash
npm install
npm install -g netlify-cli     # पहली बार
netlify dev                    # frontend + functions दोनों, http://localhost:8888
```

सिर्फ़ frontend देखना हो: `npm run dev` (तब AI call काम नहीं करेगी)।
Local पर key के लिए `.env.example` को `.env` नाम से copy करके key डाल दीजिए।

Functions को बिना API key खर्च किए जाँचना:

```bash
node scripts/test-functions.mjs
```

---

## फोल्डर का नक्शा

```
netlify.toml                 Netlify की settings + /api redirect
netlify/functions/
  analyzePalm.mjs            हथेली पढ़ने वाला AI (पहले Base44 function)
  chatWithPalmist.mjs        Guruji chat (पहले Base44 function)
  health.mjs                 deploy जाँचने के लिए
netlify/shared/
  openrouter.mjs             OpenRouter को call करने वाला हिस्सा
  guruji-prompt.mjs          👈 Guruji का skill prompt
src/
  api/client.js              Base44 SDK की जगह — सीधा fetch
  lib/storage.js             PalmReading entity की जगह — localStorage
  lib/image.js               UploadFile की जगह — browser में resize
  lib/assets.js              Guruji की images के रास्ते
  lib/i18n.js                EN/HI के सारे UI शब्द
  components/…               वही UI, Base44 के बिना
  pages/Home.jsx             मुख्य पेज
public/                      images, favicon, manifest
```

---

## ज़रूरी बातें

- **कोई login नहीं** — ऐप सबके लिए खुला है (आपके चुनाव के अनुसार)।
- **कोई database नहीं** — reading history user के browser में रहती है (localStorage), आख़िरी 20।
- **फोटो कहीं save नहीं होती** — browser में ही छोटी होकर सीधे AI को जाती है।
- **API key सिर्फ़ server पर** रहती है, browser में कभी नहीं आती।
- ऐप मनोरंजन के लिए है — footer में disclaimer मौजूद है।
