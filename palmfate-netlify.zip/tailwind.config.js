/** @type {import('tailwindcss').Config} */
// NOTE: package.json me "type": "module" hai, isliye `module.exports` ki jagah
// `export default` use kiya gaya hai (warna Netlify build fail hota hai).
import animate from 'tailwindcss-animate';

export default {
  darkMode: ['class'],
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      opacity: Object.fromEntries(Array.from({ length: 101 }, (_, i) => [i, `${i / 100}`])),
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 4px)',
        sm: 'calc(var(--radius) - 8px)'
      },
      colors: {
        background: 'hsl(var(--background))',
        foreground: 'hsl(var(--foreground))',
        border: 'hsl(var(--border))',
        ring: 'hsl(var(--ring))',
        indigo: { deep: '#0A071B', mid: '#15102E' },
        gold: { DEFAULT: '#FFD166', dim: '#E8B84A' },
        violet: { glow: '#6C5CE7' },
        cosmic: { text: '#F8F9FA', muted: '#A09ABC' }
      },
      fontFamily: {
        heading: ['var(--font-heading)'],
        body: ['var(--font-body)'],
        display: ['var(--font-display)'],
        mono: ['var(--font-mono)']
      }
    }
  },
  plugins: [animate]
};
