import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import path from 'node:path';

// Base44 ka vite-plugin hata diya gaya hai (wo sirf Base44 builder ke liye tha).
// Sirf React + '@' alias — Netlify par yahi kaafi hai.
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': path.resolve(__dirname, './src') }
  },
  server: {
    port: 5173,
    // `netlify dev` ke saath local testing ke liye /api ko functions par bhej dete hain
    proxy: {
      '/api': {
        target: 'http://localhost:8888',
        changeOrigin: true
      }
    }
  },
  build: { outDir: 'dist', sourcemap: false }
});
