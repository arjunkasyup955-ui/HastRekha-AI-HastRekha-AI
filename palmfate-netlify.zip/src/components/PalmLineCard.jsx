import React, { useState } from 'react';
import { Heart, Activity, Brain, Compass } from 'lucide-react';
import { t } from '@/lib/i18n';

const LINES = [
  { key: 'heart_line', icon: Heart, color: '#FF6B9D' },
  { key: 'life_line', icon: Activity, color: '#4FD1C5' },
  { key: 'head_line', icon: Brain, color: '#FFD166' },
  { key: 'destiny_line', icon: Compass, color: '#6C5CE7' }
];

export default function PalmLineCard({ reading, lang = 'en' }) {
  const [active, setActive] = useState('heart_line');
  const strings = t(lang);
  const current = LINES.find((l) => l.key === active) || LINES[0];
  const Icon = current.icon;
  const meta = strings.lines[current.key];

  return (
    <div className="glass rounded-2xl p-5 sm:p-6">
      <div className="flex items-center gap-2 mb-4">
        <span className="w-2 h-2 rounded-full bg-gold animate-node" />
        <h3 className="display-font text-sm tracking-widest text-gold">{strings.palmLineAnalysis}</h3>
      </div>

      {/* Line selector chips */}
      <div className="flex flex-wrap gap-2 mb-5">
        {LINES.map((l) => {
          const LineIcon = l.icon;
          const isActive = active === l.key;
          return (
            <button
              key={l.key}
              onClick={() => setActive(l.key)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                isActive ? 'text-indigo-deep' : 'glass text-muted-cosmic hover:text-cosmic-text'
              }`}
              style={isActive ? { backgroundColor: l.color } : {}}
            >
              <LineIcon className="w-3.5 h-3.5" />
              {strings.lines[l.key].label.split(' ')[0]}
            </button>
          );
        })}
      </div>

      {/* Active line detail */}
      <div className="animate-float-up" key={active + lang}>
        <div className="flex items-center gap-3 mb-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center"
            style={{ backgroundColor: `${current.color}22`, border: `1px solid ${current.color}55` }}
          >
            <Icon className="w-5 h-5" style={{ color: current.color }} />
          </div>
          <div>
            <h4 className="font-semibold text-cosmic-text">{meta.label}</h4>
            <p className="text-xs text-muted-cosmic">{meta.desc}</p>
          </div>
        </div>
        <p className="text-sm leading-relaxed text-cosmic-text/90 font-body">
          {reading?.[active] || strings.awaitingReading}
        </p>
      </div>
    </div>
  );
}
