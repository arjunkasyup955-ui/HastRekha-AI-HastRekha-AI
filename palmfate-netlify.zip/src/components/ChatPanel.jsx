import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader2 } from 'lucide-react';
import { api } from '@/api/client';
import { GURUJI_AVATAR, GURUJI_BG } from '@/lib/assets';

/**
 * BADLAV:
 *  1. `base44.functions.invoke('chatWithPalmist', …)` → `api.functions.invoke(…)`
 *     (ab call /api/chatWithPalmist Netlify function par jaati hai → OpenRouter)
 *  2. Guruji ka avatar aur chat background pehle media.base44.com se aate the.
 *     Ab local files se (`public/`), taaki Netlify par kuch bhi na toote.
 *  3. Language badalne par purani chat ab mit-ti nahi (pehle mit jaati thi).
 */
export default function ChatPanel({ reading, imageUrl, lang }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  const greeting =
    lang === 'hi'
      ? 'नमस्ते 🙏 मैं गुरुजी हूँ। मैंने आपकी हस्तरेखा देखी है। पहले बताइए, आपका नाम क्या है और आज क्या जानना चाहते हैं?'
      : 'Namaste 🙏 I am Guruji. I have seen your palm lines. First tell me, what is your name and what would you like to know today?';

  useEffect(() => {
    // Sirf tab greeting badlein jab abhi baat shuru na hui ho
    setMessages((prev) =>
      prev.length <= 1 ? [{ role: 'assistant', content: greeting }] : prev
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, sending]);

  const send = async () => {
    const text = input.trim();
    if (!text || sending) return;

    const next = [...messages, { role: 'user', content: text }];
    setMessages(next);
    setInput('');
    setSending(true);

    try {
      const readingContext = reading
        ? [
            'Summary: ' + (reading.summary || ''),
            'Heart line: ' + (reading.heart_line || ''),
            'Life line: ' + (reading.life_line || ''),
            'Head line: ' + (reading.head_line || ''),
            'Destiny line: ' + (reading.destiny_line || ''),
            'Ratings — Love: ' +
              reading.love_rating +
              ', Career: ' +
              reading.career_rating +
              ', Health: ' +
              reading.health_rating +
              ', Wealth: ' +
              reading.wealth_rating,
            'Lucky number: ' + reading.lucky_number
          ].join('\n')
        : '';

      const res = await api.functions.invoke('chatWithPalmist', {
        messages: next.map((m) => ({ role: m.role, content: m.content })),
        image_url: imageUrl,
        reading_context: readingContext,
        lang
      });

      const reply =
        res.data?.reply || (lang === 'hi' ? 'क्षमा करें, उत्तर नहीं मिला।' : 'Sorry, no reply.');
      setMessages((m) => [...m, { role: 'assistant', content: reply }]);
    } catch (e) {
      setMessages((m) => [
        ...m,
        {
          role: 'assistant',
          content:
            (lang === 'hi' ? 'क्षमा करें — ' : 'Sorry — ') +
            (e.message || (lang === 'hi' ? 'कुछ गड़बड़ हो गई।' : 'something went wrong.'))
        }
      ]);
    } finally {
      setSending(false);
    }
  };

  const suggestions =
    lang === 'hi'
      ? ['मेरा नाम राहुल है, प्रेम के बारे में बताइए', 'करियर में कब सफलता मिलेगी?', 'मेरी जीवन रेखा क्या बताती है?']
      : ['My name is Rahul, tell me about love', 'When will I succeed in career?', 'What does my life line say?'];

  return (
    <div className="glass rounded-2xl overflow-hidden flex flex-col" style={{ maxHeight: '520px' }}>
      {/* Header */}
      <div className="relative flex items-center gap-2.5 px-4 py-3 border-b border-gold/15 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: `url(${GURUJI_BG})` }}
        />
        <div className="relative">
          <div className="w-9 h-9 rounded-full glass-violet flex items-center justify-center overflow-hidden">
            <img
              src={GURUJI_AVATAR}
              alt="Guruji"
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
              }}
            />
          </div>
          <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-green-400 border-2 border-[#0A071B]" />
        </div>
        <div className="relative">
          <p className="text-sm font-semibold text-cosmic-text">{lang === 'hi' ? 'गुरुजी' : 'Guruji'}</p>
          <p className="text-[10px] text-muted-cosmic">
            {lang === 'hi' ? 'ऑनलाइन · आपकी रेखा देख रहे हैं' : 'Online · viewing your palm'}
          </p>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="relative flex-1 overflow-y-auto px-4 py-4 space-y-3 min-h-[200px]">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-[0.07] pointer-events-none"
          style={{ backgroundImage: `url(${GURUJI_BG})` }}
        />
        {messages.map((m, i) => (
          <div key={i} className={`relative flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div
              className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed whitespace-pre-wrap animate-float-up ${
                m.role === 'user'
                  ? 'bg-gold text-indigo-deep font-medium rounded-br-sm'
                  : 'glass text-cosmic-text/90 rounded-bl-sm'
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}

        {sending && (
          <div className="relative flex justify-start">
            <div className="glass rounded-2xl rounded-bl-sm px-4 py-3 flex items-center gap-2">
              <Loader2 className="w-4 h-4 text-gold animate-spin" />
              <span className="text-xs text-muted-cosmic">
                {lang === 'hi' ? 'रेखाएँ देख रहा हूँ…' : 'Reading the lines…'}
              </span>
            </div>
          </div>
        )}

        {messages.length <= 1 && !sending && (
          <div className="relative flex flex-wrap gap-2 pt-2">
            {suggestions.map((s, i) => (
              <button
                key={i}
                onClick={() => setInput(s)}
                className="text-xs glass-violet text-cosmic-text/80 rounded-full px-3 py-1.5 hover:bg-gold/10 transition-colors"
              >
                {s}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Input */}
      <div className="border-t border-gold/15 p-3 flex items-center gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') send();
          }}
          placeholder={lang === 'hi' ? 'अपना प्रश्न लिखें…' : 'Type your question…'}
          className="flex-1 bg-transparent text-sm text-cosmic-text placeholder:text-muted-cosmic outline-none px-2"
        />
        <button
          onClick={send}
          disabled={sending || !input.trim()}
          className="w-9 h-9 rounded-xl bg-gold text-indigo-deep flex items-center justify-center disabled:opacity-40 hover:bg-gold-dim transition-colors shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
