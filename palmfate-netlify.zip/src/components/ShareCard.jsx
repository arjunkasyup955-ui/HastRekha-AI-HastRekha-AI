import React, { useRef, useState } from 'react';
import { Download, Share2, Sparkles } from 'lucide-react';
import { t } from '@/lib/i18n';

export default function ShareCard({ reading, lang = 'en' }) {
  const cardRef = useRef(null);
  const [downloading, setDownloading] = useState(false);
  const strings = t(lang);

  const handleDownload = async () => {
    if (!cardRef.current) return;
    setDownloading(true);
    try {
      const html2canvas = (await import('html2canvas')).default;
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: '#0A071B',
        scale: 2,
        useCORS: true
      });
      const link = document.createElement('a');
      link.download = 'palmfate-reading.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch {
      /* silent */
    }
    setDownloading(false);
  };

  const handleShare = async () => {
    const text =
      lang === 'hi'
        ? `🔮 मेरी PalmFate रीडिंग — ${reading?.overall_fortune || 'शुभ'}! शुभ अंक ${reading?.lucky_number}। आप भी मुफ़्त में देखिए — PalmFate.`
        : `🔮 My PalmFate reading — ${reading?.overall_fortune || 'Auspicious'}! Lucky number ${reading?.lucky_number}. Get yours free at PalmFate.`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'PalmFate', text });
      } catch {
        /* user cancelled */
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
      } catch {
        /* clipboard blocked */
      }
    }
  };

  return (
    <div>
      <div
        ref={cardRef}
        className="relative aspect-[9/16] max-w-[320px] mx-auto rounded-2xl overflow-hidden cosmic-gradient p-6 flex flex-col"
        style={{ border: '1px solid rgba(255,209,102,0.25)' }}
      >
        <div className="absolute top-4 right-4 text-gold/40 text-xs">✦ ✦ ✦</div>
        <div className="absolute bottom-4 left-4 text-violet-glow/40 text-xs">✦ ✦</div>

        <div className="text-center mb-4">
          <p className="display-font text-gold text-xs tracking-[0.3em]">PALMFATE</p>
          <h2 className="display-font text-2xl text-cosmic-text mt-1 leading-tight">
            {reading?.overall_fortune || 'Auspicious'}
          </h2>
        </div>

        <p className="text-xs text-cosmic-text/80 text-center leading-relaxed mb-4 line-clamp-4">
          {reading?.summary}
        </p>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <MiniGauge label={strings.ratings.love} value={reading?.love_rating} color="#FF6B9D" />
          <MiniGauge label={strings.ratings.career} value={reading?.career_rating} color="#FFD166" />
          <MiniGauge label={strings.ratings.health} value={reading?.health_rating} color="#6C5CE7" />
          <MiniGauge label={strings.ratings.wealth} value={reading?.wealth_rating} color="#4FD1C5" />
        </div>

        <div className="mt-auto text-center">
          <div className="inline-flex items-center gap-2 glass-violet rounded-full px-4 py-1.5">
            <Sparkles className="w-3.5 h-3.5 text-gold" />
            <span className="text-xs text-cosmic-text">
              {strings.luckyNumber}{' '}
              <span className="display-font text-gold text-base">{reading?.lucky_number}</span>
            </span>
          </div>
          <p className="text-[10px] text-muted-cosmic mt-3 tracking-widest">PalmFate · AI Palm Reading</p>
        </div>
      </div>

      <div className="flex gap-3 mt-4 max-w-[320px] mx-auto">
        <button
          onClick={handleDownload}
          disabled={downloading}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gold text-indigo-deep font-semibold text-sm hover:bg-gold-dim transition-colors disabled:opacity-60"
        >
          <Download className="w-4 h-4" /> {downloading ? strings.saving : strings.saveStory}
        </button>
        <button
          onClick={handleShare}
          className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl glass text-gold text-sm font-medium hover:bg-gold/10 transition-colors"
        >
          <Share2 className="w-4 h-4" /> {strings.share}
        </button>
      </div>
    </div>
  );
}

function MiniGauge({ label, value, color }) {
  const v = Math.round(value || 0);
  const c = 2 * Math.PI * 15;
  return (
    <div className="glass rounded-xl p-2.5 flex items-center gap-2">
      <div className="relative w-9 h-9 shrink-0">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
          <circle cx="18" cy="18" r="15" stroke="rgba(255,255,255,0.1)" strokeWidth="3" fill="none" />
          <circle
            cx="18"
            cy="18"
            r="15"
            stroke={color}
            strokeWidth="3"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={c}
            strokeDashoffset={c - (v / 100) * c}
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-[10px] text-cosmic-text font-semibold">
          {v}
        </span>
      </div>
      <span className="text-xs text-muted-cosmic">{label}</span>
    </div>
  );
}
