import React, { useRef, useState } from 'react';
import { Upload, Camera, Sparkles, Loader2 } from 'lucide-react';
import { prepareImage } from '@/lib/image';
import { t } from '@/lib/i18n';

/**
 * BADLAV: pehle yahan `base44.integrations.Core.UploadFile({ file })` chalta tha
 * aur photo Base44 storage par chali jaati thi. Ab photo browser me hi resize
 * hokar data-URL banti hai (@/lib/image) — koi upload, koi storage nahi.
 */
export default function PalmScanner({ onAnalyze, loading, hasResult, lang = 'en' }) {
  const fileRef = useRef(null);
  const cameraRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [preview, setPreview] = useState(null);
  const [error, setError] = useState('');
  const strings = t(lang);

  const handleFile = async (file) => {
    setError('');
    if (!file) return;
    try {
      const { full, thumb } = await prepareImage(file);
      setPreview(full);
      onAnalyze(full, thumb);
    } catch (err) {
      setError(err.message || 'Could not read the image. Please try again.');
    }
  };

  return (
    <div className="w-full">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          handleFile(e.dataTransfer.files[0]);
        }}
        className={`relative rounded-2xl overflow-hidden transition-all duration-300 ${
          dragOver ? 'glow-gold scale-[1.01]' : ''
        } glass ${preview ? 'p-0' : 'p-6 sm:p-8'}`}
      >
        {preview ? (
          <div className="relative aspect-[4/5] sm:aspect-square w-full">
            <img src={preview} alt="Your palm" className="w-full h-full object-cover opacity-90" />
            {/* Scanner overlay */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-deep/40 via-transparent to-indigo-deep/30" />
              <div className="absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent animate-laser shadow-[0_0_12px_#FFD166]" />
              <Node className="top-[28%] left-[20%]" delay="0s" />
              <Node className="top-[40%] left-[68%]" delay="0.4s" />
              <Node className="top-[55%] left-[30%]" delay="0.8s" />
              <Node className="top-[68%] left-[60%]" delay="1.2s" />
              {/* FIX: purane code me path ke coordinates "20%" the — SVG path me
                  percentage chalta hi nahi, isliye ye dashed line kabhi dikhti
                  hi nahi thi (console me error aata tha). Ab viewBox 0-100 hai. */}
              <svg
                className="absolute inset-0 w-full h-full"
                viewBox="0 0 100 100"
                preserveAspectRatio="none"
              >
                <path
                  d="M 20 28 L 68 40 L 30 55 L 60 68"
                  stroke="#FFD166"
                  strokeWidth="0.4"
                  fill="none"
                  strokeDasharray="1.5 2.5"
                  opacity="0.5"
                  vectorEffect="non-scaling-stroke"
                />
              </svg>
            </div>
            {loading && (
              <div className="absolute inset-0 bg-indigo-deep/60 flex flex-col items-center justify-center gap-3">
                <Loader2 className="w-8 h-8 text-gold animate-spin" />
                <p className="text-gold display-font text-sm tracking-widest">{strings.readingLines}</p>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center text-center min-h-[260px]">
            <div className="relative mb-5">
              <div className="absolute inset-0 rounded-full bg-gold/20 animate-pulse-ring" />
              <div className="relative w-16 h-16 rounded-full glass flex items-center justify-center glow-gold">
                <Sparkles className="w-7 h-7 text-gold" />
              </div>
            </div>
            <h3 className="display-font text-lg text-cosmic-text mb-1">{strings.revealTitle}</h3>
            <p className="text-muted-cosmic text-sm max-w-xs mb-5">{strings.revealSub}</p>
            <div className="flex flex-col sm:flex-row gap-3 w-full max-w-sm">
              <button
                onClick={() => fileRef.current?.click()}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gold text-indigo-deep font-semibold hover:bg-gold-dim transition-colors"
              >
                <Upload className="w-4 h-4" /> {strings.uploadPhoto}
              </button>
              <button
                onClick={() => cameraRef.current?.click()}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl glass text-gold hover:bg-gold/10 transition-colors"
              >
                <Camera className="w-4 h-4" /> {strings.camera}
              </button>
            </div>
          </div>
        )}

        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFile(e.target.files[0])}
        />
        <input
          ref={cameraRef}
          type="file"
          accept="image/*"
          capture="environment"
          className="hidden"
          onChange={(e) => handleFile(e.target.files[0])}
        />
      </div>

      {error && <p className="mt-3 text-sm text-red-400 text-center">{error}</p>}

      {!preview && !hasResult && (
        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-cosmic">
          <Sparkles className="w-3 h-3 text-gold" />
          {strings.freeReading}
        </div>
      )}
    </div>
  );
}

function Node({ className = '', delay = '0s' }) {
  return (
    <div className={`absolute ${className}`} style={{ animationDelay: delay }}>
      <div className="w-3 h-3 rounded-full bg-gold animate-node shadow-[0_0_10px_#FFD166]" />
    </div>
  );
}
