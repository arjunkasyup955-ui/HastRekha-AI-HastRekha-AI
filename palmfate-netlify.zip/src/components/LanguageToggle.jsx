import React from 'react';

export default function LanguageToggle({ lang, setLang }) {
  return (
    <div className="flex items-center gap-1 glass rounded-full p-1">
      {[
        { code: 'en', label: 'EN' },
        { code: 'hi', label: 'हिं' }
      ].map((opt) => (
        <button
          key={opt.code}
          onClick={() => setLang(opt.code)}
          className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
            lang === opt.code ? 'bg-gold text-indigo-deep' : 'text-muted-cosmic hover:text-cosmic-text'
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}
