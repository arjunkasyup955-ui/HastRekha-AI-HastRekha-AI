import React, { useEffect, useRef } from 'react';

// Base44 se koi lena-dena nahi tha — jaisa tha waisa hi rakha gaya hai.
export default function StarfieldCanvas({ density = 80, className = '' }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    let stars = [];

    const resize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;
      const dpr = window.devicePixelRatio || 1;
      canvas.width = parent.offsetWidth * dpr;
      canvas.height = parent.offsetHeight * dpr;
      canvas.style.width = parent.offsetWidth + 'px';
      canvas.style.height = parent.offsetHeight + 'px';
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.scale(dpr, dpr);
      stars = Array.from({ length: density }, () => ({
        x: Math.random() * parent.offsetWidth,
        y: Math.random() * parent.offsetHeight,
        r: Math.random() * 1.4 + 0.3,
        a: Math.random(),
        speed: Math.random() * 0.015 + 0.005,
        gold: Math.random() > 0.7
      }));
    };

    const draw = () => {
      const parent = canvas.parentElement;
      if (parent) {
        ctx.clearRect(0, 0, parent.offsetWidth, parent.offsetHeight);
        stars.forEach((s) => {
          s.a += s.speed;
          const twinkle = (Math.sin(s.a) + 1) / 2;
          ctx.beginPath();
          ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
          ctx.fillStyle = s.gold
            ? `rgba(255, 209, 102, ${0.3 + twinkle * 0.6})`
            : `rgba(248, 249, 250, ${0.2 + twinkle * 0.5})`;
          ctx.fill();
        });
      }
      raf = requestAnimationFrame(draw);
    };

    resize();
    draw();
    window.addEventListener('resize', resize);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
    };
  }, [density]);

  return <canvas ref={canvasRef} className={`absolute inset-0 w-full h-full ${className}`} />;
}
