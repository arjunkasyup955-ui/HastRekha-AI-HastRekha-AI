import React from 'react';
import { t } from '@/lib/i18n';

const COLORS = {
  love: '#FF6B9D',
  career: '#FFD166',
  health: '#6C5CE7',
  wealth: '#4FD1C5'
};

export default function RatingGauge({ type, value, lang = 'en' }) {
  const color = COLORS[type] || COLORS.love;
  const label = t(lang).ratings[type] || type;
  const v = Math.round(value || 0);
  const circumference = 2 * Math.PI * 34;
  const offset = circumference - (v / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="relative w-20 h-20">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 80 80">
          <circle cx="40" cy="40" r="34" stroke="rgba(255,255,255,0.08)" strokeWidth="5" fill="none" />
          <circle
            cx="40"
            cy="40"
            r="34"
            stroke={color}
            strokeWidth="5"
            fill="none"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{ transition: 'stroke-dashoffset 1s ease-out', filter: `drop-shadow(0 0 4px ${color})` }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="display-font text-lg text-cosmic-text">{v}</span>
        </div>
      </div>
      <span className="text-xs text-muted-cosmic font-medium">{label}</span>
    </div>
  );
}
