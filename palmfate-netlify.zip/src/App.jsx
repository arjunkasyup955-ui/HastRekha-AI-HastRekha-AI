/**
 * App root.
 * ─────────
 * Pehle yahan Base44 ka poora auth stack tha: AuthProvider, react-query,
 * BrowserRouter, ProtectedRoute, Login/Register/ForgotPassword/ResetPassword,
 * OAuthConsent aur UserNotRegisteredError.
 *
 * Aapke faisle ke mutabik login hata diya gaya hai — app public hai, isliye
 * ab sirf Home render hota hai. Routing ki zaroorat nahi rahi (netlify.toml
 * ka SPA redirect har URL ko yahin le aata hai).
 */
import React from 'react';
import Home from '@/pages/Home';

export default function App() {
  return <Home />;
}
