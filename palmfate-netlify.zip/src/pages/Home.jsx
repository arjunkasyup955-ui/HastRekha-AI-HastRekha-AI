import React, { useEffect, useState } from 'react';
import { Sparkles, Crown, RefreshCw, Star, Zap } from 'lucide-react';
import { api } from '@/api/client';
import { PalmReadingStore } from '@/lib/storage';
import { t } from '@/lib/i18n';
import StarfieldCanvas from '@/components/StarfieldCanvas';
import PalmScanner from '@/components/PalmScanner';
import PalmLineCard from '@/components/PalmLineCard';
import RatingGauge from '@/components/RatingGauge';
import ShareCard from '@/components/ShareCard';
import LanguageToggle from '@/components/LanguageToggle';
import ChatPanel from '@/components/ChatPanel';

/**
 * BADLAV (Base44 → Netlify):
 *  - base44.entities.PalmReading.list/create  →  PalmReadingStore (localStorage)
 *  - base44.functions.invoke('analyzePalm')   →  api.functions.invoke(...) → Netlify function
 *  - photo ab data-URL hai (upload nahi hoti); history me sirf chhota thumbnail save hota hai
 *  - poora UI ab EN/HI dono me
 */
export default function Home() {
  const [loading, setLoading] = useState(false);
  const [reading, setReading] = useState(null);
  const [recent, setRecent] = useState(null);
  const [error, setError] = useState('');
  const [lang, setLang] = useState('en');
  const [currentImage, setCurrentImage] = useState(null);

  useEffect(() => {
    loadRecent();
  }, []);

  const loadRecent = async () => {
    try {
      const list = await PalmReadingStore.list('-created_date', 1);
      if (list && list.length > 0) {
        setRecent(list[0]);
        if (list[0].image_url) setCurrentImage(list[0].image_url);
      }
    } catch {
      /* history optional hai */
    }
  };

  const handleAnalyze = async (imageUrl, thumbUrl) => {
    setLoading(true);
    setError('');
    setReading(null);
    setCurrentImage(imageUrl);

    try {
      const res = await api.functions.invoke('analyzePalm', { image_url: imageUrl });
      const r = res.data?.reading;
      if (!r) throw new Error(res.data?.error || 'Reading failed');
      setReading(r);

      try {
        // History me poori photo nahi — sirf halka thumbnail (localStorage ki limit)
        const saved = await PalmReadingStore.create({ image_url: thumbUrl || null, ...r });
        setRecent(saved);
      } catch {
        /* save fail ho to bhi reading dikhti rahe */
      }
    } catch (err) {
      setError(err.message || 'The cosmos could not be reached. Try again.');
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setReading(null);
    setError('');
    setCurrentImage(null);
  };

  const applyLang = (r) => {
    if (!r) return r;
    const pick = (f) => (lang === 'hi' ? r[`${f}_hi`] || r[f] : r[f]);
    return {
      ...r,
      summary: pick('summary'),
      overall_fortune: pick('overall_fortune'),
      heart_line: pick('heart_line'),
      life_line: pick('life_line'),
      head_line: pick('head_line'),
      destiny_line: pick('destiny_line')
    };
  };

  const display = applyLang(reading || (recent && !loading ? recent : null));

  const shared = {
    loading,
    reading: display,
    error,
    onAnalyze: handleAnalyze,
    onReset: reset,
    hasFresh: !!reading,
    rawReading: reading || recent,
    imageUrl: currentImage,
    lang
  };

  return (
    <div className="min-h-screen cosmic-gradient text-cosmic-text font-body relative overflow-x-hidden">
      <StarfieldCanvas density={70} className="fixed" />
      <div className="relative z-10">
        <Header lang={lang} setLang={setLang} />
        <DesktopLayout {...shared} />
        <MobileLayout {...shared} />
        <Footer lang={lang} />
      </div>
    </div>
  );
}

function Header({ lang, setLang }) {
  const s = t(lang);
  return (
    <header className="px-5 sm:px-10 pt-6 pb-2 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-lg glass flex items-center justify-center glow-gold">
          <Sparkles className="w-4 h-4 text-gold" />
        </div>
        <span className="display-font text-lg text-gold tracking-wider">PalmFate</span>
      </div>
      <div className="flex items-center gap-2">
        <div className="hidden sm:flex items-center gap-2 glass rounded-full px-3 py-1.5">
          <Star className="w-3.5 h-3.5 text-gold" />
          <span className="text-xs text-muted-cosmic">{s.aiPalmReading}</span>
        </div>
        <LanguageToggle lang={lang} setLang={setLang} />
      </div>
    </header>
  );
}

function UnlockBadge({ lang }) {
  const s = t(lang);
  return (
    <div className="glass-violet rounded-2xl p-4 flex items-center gap-3">
      <div className="w-10 h-10 rounded-xl bg-gold/15 flex items-center justify-center shrink-0">
        <Crown className="w-5 h-5 text-gold" />
      </div>
      <div className="flex-1">
        <p className="text-sm font-semibold text-cosmic-text">{s.unlimitedPass}</p>
        <p className="text-xs text-muted-cosmic">{s.unlimitedSub}</p>
      </div>
      <div className="text-right">
        <p className="display-font text-lg text-gold">₹149</p>
        <p className="text-[10px] text-muted-cosmic">{s.perMonth}</p>
      </div>
    </div>
  );
}

function DesktopLayout({ loading, reading, error, onAnalyze, onReset, hasFresh, rawReading, imageUrl, lang }) {
  const s = t(lang);
  return (
    <div className="hidden md:block">
      <div className="flex max-w-7xl mx-auto px-10 gap-10 py-8">
        {/* Left 45% sticky */}
        <div className="w-[45%] sticky top-8 self-start space-y-6">
          <div>
            <p className="text-gold text-sm tracking-[0.25em] mb-3 display-font">{s.tagline}</p>
            <h1
              className="display-font font-black leading-[1.05] text-cosmic-text"
              style={{ fontSize: 'clamp(2.5rem, 6vw, 4.5rem)' }}
            >
              {s.heroTitle1}
              <br />
              {s.heroTitle2}
            </h1>
            <p className="text-muted-cosmic mt-4 max-w-sm text-[0.95rem] leading-relaxed">{s.heroSub}</p>
          </div>

          <PalmScanner onAnalyze={onAnalyze} loading={loading} hasResult={!!reading} lang={lang} />

          {hasFresh && (
            <button
              onClick={onReset}
              className="flex items-center gap-2 text-sm text-muted-cosmic hover:text-gold transition-colors"
            >
              <RefreshCw className="w-4 h-4" /> {s.scanAnother}
            </button>
          )}

          <UnlockBadge lang={lang} />
        </div>

        {/* Right 55% scrollable */}
        <div className="w-[55%] space-y-6">
          {error && (
            <div className="glass rounded-2xl p-4 text-red-300 text-sm flex items-center gap-2">
              <Zap className="w-4 h-4 shrink-0" /> {error}
            </div>
          )}

          {reading ? (
            <>
              <PredictionPreview reading={reading} lang={lang} />
              <PalmLineCard reading={reading} lang={lang} />
              <RatingGrid reading={reading} lang={lang} />
              <div>
                <h3 className="display-font text-sm tracking-widest text-gold mb-4">{s.shareableStory}</h3>
                <ShareCard reading={reading} lang={lang} />
              </div>
              <div>
                <h3 className="display-font text-sm tracking-widest text-gold mb-4">{s.askPalmist}</h3>
                <ChatPanel reading={rawReading} imageUrl={imageUrl} lang={lang} />
              </div>
            </>
          ) : (
            <EmptyState loading={loading} lang={lang} />
          )}
        </div>
      </div>
    </div>
  );
}

function MobileLayout({ loading, reading, error, onAnalyze, onReset, hasFresh, rawReading, imageUrl, lang }) {
  const s = t(lang);
  return (
    <div className="md:hidden">
      <div className="relative px-5 pt-8 pb-6 text-center">
        <div className="absolute inset-0 bg-gradient-to-b from-violet-glow/15 to-transparent pointer-events-none" />
        <p className="text-gold text-xs tracking-[0.3em] mb-2 display-font relative">✦ PALMFATE ✦</p>
        <h1
          className="display-font font-black leading-[1.1] text-cosmic-text relative"
          style={{ fontSize: 'clamp(2rem, 9vw, 3rem)' }}
        >
          {s.mobileTitle1}
          <br />
          {s.mobileTitle2}
        </h1>
        <p className="text-muted-cosmic mt-3 text-sm max-w-xs mx-auto relative">{s.mobileSub}</p>
      </div>

      <div className="px-5 space-y-5 pb-28">
        {error && (
          <div className="glass rounded-2xl p-3 text-red-300 text-sm flex items-center gap-2">
            <Zap className="w-4 h-4 shrink-0" /> {error}
          </div>
        )}

        <PalmScanner onAnalyze={onAnalyze} loading={loading} hasResult={!!reading} lang={lang} />

        {hasFresh && (
          <button
            onClick={onReset}
            className="w-full flex items-center justify-center gap-2 text-sm text-muted-cosmic hover:text-gold transition-colors py-2"
          >
            <RefreshCw className="w-4 h-4" /> {s.scanAnother}
          </button>
        )}

        {reading ? (
          <>
            <PredictionPreview reading={reading} lang={lang} />
            <PalmLineCard reading={reading} lang={lang} />
            <RatingGrid reading={reading} lang={lang} />
            <div>
              <h3 className="display-font text-sm tracking-widest text-gold mb-3 text-center">{s.shareableStory}</h3>
              <ShareCard reading={reading} lang={lang} />
            </div>
            <div>
              <h3 className="display-font text-sm tracking-widest text-gold mb-3 text-center">{s.askPalmist}</h3>
              <ChatPanel reading={rawReading} imageUrl={imageUrl} lang={lang} />
            </div>
          </>
        ) : (
          <SampleCarousel lang={lang} />
        )}
      </div>

      {/* Bottom fixed bar */}
      <div className="fixed bottom-0 left-0 right-0 z-20 glass border-t border-gold/20 px-5 py-3 flex items-center justify-between">
        <div>
          <p className="text-xs text-muted-cosmic">{s.unlimitedReadings}</p>
          <p className="display-font text-gold text-lg leading-none">
            ₹149<span className="text-xs text-muted-cosmic font-body">{s.perMonth}</span>
          </p>
        </div>
        <button className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gold text-indigo-deep font-semibold text-sm glow-gold">
          <Crown className="w-4 h-4" /> {s.unlockPass}
        </button>
      </div>
    </div>
  );
}

function PredictionPreview({ reading, lang }) {
  const s = t(lang);
  return (
    <div className="glass rounded-2xl p-5 sm:p-6 animate-float-up">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-gold animate-node" />
          <h3 className="display-font text-sm tracking-widest text-gold">{s.aiPrediction}</h3>
        </div>
        <span className="display-font text-lg text-gold">{reading?.overall_fortune}</span>
      </div>
      <p className="text-cosmic-text/90 leading-relaxed text-[0.95rem]">{reading?.summary}</p>
      <div className="mt-4 flex items-center gap-2 text-xs text-muted-cosmic">
        <Sparkles className="w-3.5 h-3.5 text-gold" />
        {s.luckyNumber}{' '}
        <span className="display-font text-gold text-base ml-1">{reading?.lucky_number}</span>
      </div>
    </div>
  );
}

function RatingGrid({ reading, lang }) {
  const s = t(lang);
  return (
    <div className="glass rounded-2xl p-5 sm:p-6">
      <div className="flex items-center gap-2 mb-5">
        <span className="w-2 h-2 rounded-full bg-gold animate-node" />
        <h3 className="display-font text-sm tracking-widest text-gold">{s.cosmicRatings}</h3>
      </div>
      <div className="grid grid-cols-4 gap-2 sm:gap-4">
        <RatingGauge type="love" value={reading?.love_rating} lang={lang} />
        <RatingGauge type="career" value={reading?.career_rating} lang={lang} />
        <RatingGauge type="health" value={reading?.health_rating} lang={lang} />
        <RatingGauge type="wealth" value={reading?.wealth_rating} lang={lang} />
      </div>
    </div>
  );
}

function EmptyState({ loading, lang }) {
  const s = t(lang);
  return (
    <div className="glass rounded-2xl p-8 text-center">
      <div className="w-14 h-14 rounded-full glass-violet flex items-center justify-center mx-auto mb-4">
        <Sparkles className="w-6 h-6 text-gold" />
      </div>
      <h3 className="display-font text-lg text-cosmic-text mb-2">
        {loading ? s.loadingTitle : s.awaitingTitle}
      </h3>
      <p className="text-muted-cosmic text-sm max-w-sm mx-auto">{loading ? s.loadingSub : s.awaitingSub}</p>
    </div>
  );
}

function SampleCarousel({ lang }) {
  const s = t(lang);
  const samples =
    lang === 'hi'
      ? [
          { line: 'हृदय रेखा', text: 'गहरी और मुड़ी हुई हृदय रेखा प्रेम में उदार और भावुक स्वभाव बताती है — इस मौसम रोमांस आपके पक्ष में है।', color: '#FF6B9D' },
          { line: 'जीवन रेखा', text: 'मज़बूत, घुमावदार जीवन रेखा भरपूर ऊर्जा और हर बदलाव में टिके रहने की ताक़त दिखाती है।', color: '#4FD1C5' },
          { line: 'मस्तिष्क रेखा', text: 'लंबी, सीधी मस्तिष्क रेखा तर्कशील और एकाग्र मन की निशानी है — रणनीति आपकी ताक़त है।', color: '#FFD166' },
          { line: 'भाग्य रेखा', text: 'साफ़ भाग्य रेखा कहती है कि आपका रास्ता तय है — लगन से सफलता ज़रूर मिलेगी।', color: '#6C5CE7' }
        ]
      : [
          { line: 'Heart Line', text: 'A deep, curved heart line reveals a passionate, generous love nature — romance favors you this season.', color: '#FF6B9D' },
          { line: 'Life Line', text: 'A strong, curving life line signals abundant vitality and resilience through change.', color: '#4FD1C5' },
          { line: 'Head Line', text: 'A long, straight head line points to a logical, focused mind suited to strategy and analysis.', color: '#FFD166' },
          { line: 'Destiny Line', text: 'A clear destiny line suggests your path is set — success comes through persistence.', color: '#6C5CE7' }
        ];

  return (
    <div className="glass rounded-2xl p-5">
      <h3 className="display-font text-sm tracking-widest text-gold mb-4 text-center">{s.sampleReadings}</h3>
      <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1 snap-x">
        {samples.map((sample, i) => (
          <div key={i} className="min-w-[220px] snap-center glass-violet rounded-xl p-4">
            <div className="w-2 h-2 rounded-full mb-2" style={{ backgroundColor: sample.color }} />
            <p className="text-xs font-semibold mb-1" style={{ color: sample.color }}>
              {sample.line}
            </p>
            <p className="text-xs text-cosmic-text/80 leading-relaxed">{sample.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function Footer({ lang }) {
  return (
    <footer className="hidden md:block text-center py-8 text-xs text-muted-cosmic/60">
      <p>{t(lang).disclaimer}</p>
    </footer>
  );
}
