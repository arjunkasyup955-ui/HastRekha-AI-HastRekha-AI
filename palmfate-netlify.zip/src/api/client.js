/**
 * Base44 SDK client ka replacement.
 * ─────────────────────────────────
 * Pehle: `import { base44 } from '@/api/base44Client'` → base44.functions.invoke(...)
 *        (SDK ko appId, token, appBaseUrl chahiye tha — sab Base44 ka apna tha)
 * Ab:    seedha Netlify Functions ko fetch. Koi SDK, koi token, koi app-id nahi.
 *
 * Response shape jaan-boojh kar wahi rakha gaya hai — { data } — taaki
 * frontend code (res.data?.reading, res.data?.reply) bilkul waisa hi chale.
 */

const FUNCTIONS_BASE = '/api'; // netlify.toml me /.netlify/functions par redirect hai

async function invoke(name, body = {}) {
  let res;
  try {
    res = await fetch(`${FUNCTIONS_BASE}/${name}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
  } catch {
    throw new Error('Network se connect nahi ho paya. Internet check karke dobara koshish karein.');
  }

  let data = {};
  try {
    data = await res.json();
  } catch {
    /* empty body */
  }

  if (!res.ok) {
    throw new Error(data?.error || `Request failed (${res.status})`);
  }
  return { data };
}

export const api = {
  functions: { invoke }
};

export default api;
