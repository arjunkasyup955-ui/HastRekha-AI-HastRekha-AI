# क्या-क्या बदला और क्यों

नीचे हर उस चीज़ की सूची है जो Base44 पर टिकी हुई थी, और अब उसकी जगह क्या आया।

---

## 1. Base44 SDK client → सीधा fetch

**पहले:** `src/api/base44Client.js` + `src/lib/app-params.js`
`createClient({ appId, token, functionsVersion, appBaseUrl })` — यह चारों values
Base44 के अपने env variables (`VITE_BASE44_*`) से आती थीं। Netlify पर ये कभी नहीं मिलतीं,
इसलिए ऐप पहली ही line पर मर जाता।

**अब:** `src/api/client.js` — सिर्फ़ `fetch('/api/<function>')`.
कोई SDK, कोई app-id, कोई token नहीं।
**क्यों:** response का आकार जान-बूझकर वही रखा (`{ data }`), इसलिए पुराना code
`res.data?.reading` / `res.data?.reply` बिना बदले चलता है।

## 2. Login / Auth का पूरा stack → हटाया गया

**पहले:** `AuthContext.jsx`, `ProtectedRoute.jsx`, `Login`, `Register`,
`ForgotPassword`, `ResetPassword`, `OAuthConsent`, `UserNotRegisteredError`,
`authReturnTo.js`, `AuthLayout`, `GoogleIcon` — सब `base44.auth.*` पर चलते थे
(Google OAuth, OTP, password reset — सब Base44 का server करता था)।

**अब:** आपके चुनाव के मुताबिक़ **login हटा दिया गया** — ऐप public है।
`App.jsx` अब सिर्फ़ `Home` दिखाता है।
**क्यों:** मुफ़्त हस्तरेखा के लिए login की ज़रूरत नहीं थी, और Netlify पर उन pages को
ज़िंदा रखने के लिए एक पूरा auth server चाहिए होता।
*(आगे कभी login चाहिए हो तो Netlify Identity से जोड़ा जा सकता है।)*

## 3. `PalmReading` entity (database) → browser का localStorage

**पहले:** `base44.entities.PalmReading.list('-created_date', 1)` और `.create({...})`
— Base44 का hosted database.

**अब:** `src/lib/storage.js` → `PalmReadingStore.list()` / `.create()`.
Methods `async` ही रखे गए, इसलिए `Home.jsx` का `await` वाला code वैसा ही चलता है।
आख़िरी **20** readings रखी जाती हैं; localStorage भर जाए तो पुरानी अपने-आप हट जाती हैं।
**क्यों:** आपने "browser में save" चुना — इसमें कोई database, कोई user-id, कोई खर्च नहीं।

## 4. `analyzePalm` backend function → Netlify Function + OpenRouter

**पहले:** `base44.functions.invoke('analyzePalm')` — Base44 का अपना AI.

**अब:** `netlify/functions/analyzePalm.mjs`
- OpenRouter के vision model को फोटो भेजता है
- सख़्त JSON माँगता है और उसे साफ़ करके वही आकार लौटाता है जिसकी UI को आदत है
- `love/career/health/wealth` को 0–100 में clamp करता है (AI कभी 812 भेज दे तो भी UI न टूटे)
- फोटो हथेली की न हो तो साफ़ हिंदी+English message देता है
- ```` ```json ```` fence लगा जवाब भी सही parse होता है

## 5. `chatWithPalmist` backend function → Netlify Function + आपका Guruji prompt

**अब:** `netlify/functions/chatWithPalmist.mjs`
- आपका पूरा **astrologer skill prompt** `netlify/shared/guruji-prompt.mjs` में है
  (पहले यह Base44 के settings field में छिपा था — अब code में, कभी भी बदल सकते हैं)
- भाषा (EN/HI), reading का context, और safety के नियम उसी system prompt में जुड़ते हैं
- हथेली का फोटो सिर्फ़ **पहले** user message के साथ जाता है, हर बार नहीं — इससे हर जवाब
  सस्ता और तेज़ रहता है
- history के आख़िरी 16 messages ही भेजे जाते हैं

## 6. `UploadFile` (फोटो storage) → browser में resize, कोई upload नहीं

**पहले:** `base44.integrations.Core.UploadFile({ file })` → फोटो Base44 के storage पर
जाती थी और उसका public URL AI को भेजा जाता था।

**अब:** `src/lib/image.js`
- फोटो browser में ही छोटी होती है: AI के लिए max 1152px (≈200KB), history के लिए 400px thumbnail
- data-URL सीधे function को जाती है — **कहीं save नहीं होती**
- फ़ोन की घुमी हुई फोटो अपने-आप सीधी होती है (EXIF orientation)
**क्यों:** storage bucket की ज़रूरत ख़त्म, privacy बेहतर, और localStorage भरता नहीं।

## 7. Guruji की images → Base44 CDN से आपके `public/` फोल्डर में

**पहले:** `https://media.base44.com/images/public/6a99656.../…png` (avatar + chat background)।
Base44 खाता बंद होते ही ये तस्वीरें ग़ायब हो जातीं।

**अब:** `public/guruji-bg.svg` और `public/guruji-avatar.svg`, रास्ते एक ही जगह
`src/lib/assets.js` में। आपकी असली image डालने का तरीका README में है।
*(आपने जो zodiac-wheel image भेजी थी वह chat तक file के रूप में नहीं पहुँची, इसलिए उसी
मिज़ाज का एक cosmic zodiac SVG बनाकर लगाया है — आपकी PNG डालते ही वह हट जाएगा।)*

## 8. Build setup → Base44 plugin के बिना

- `vite.config.js`: `@base44/vite-plugin` (hmrNotifier, visualEditAgent, analyticsTracker —
  सब Builder के लिए थे) हटाया; `@` alias जोड़ा।
- `package.json`: `@base44/sdk`, `@base44/vite-plugin`, सारे Radix UI packages,
  react-query, react-router, stripe, three.js, leaflet, quill आदि हटाए —
  **60+ dependencies से घटकर 6** रह गईं (build तेज़, टूटने की गुंजाइश कम)।
- `tailwind.config.js`: `module.exports` → `export default`
  (**ज़रूरी fix** — `"type": "module"` के साथ पुराना वाला Netlify पर build तोड़ देता)।
- `shadcn/ui` के 40+ फ़ाइल वाले `components/ui/` फोल्डर की ज़रूरत नहीं रही, क्योंकि
  Home page उनमें से एक भी इस्तेमाल नहीं करता था — सिर्फ़ auth pages करते थे।
- `netlify.toml` नया: build settings, `/api/*` → functions redirect, SPA redirect, security headers।

## 9. साथ में ठीक की गई एक पुरानी बग

`PalmScanner.jsx` में scanner की dashed connecting-line इस तरह लिखी थी:
`d="M 20% 28% L 68% 40% …"` — SVG के path में **percentage चलता ही नहीं**, इसलिए वह
line कभी दिखती नहीं थी और browser console में error आता था।
अब `viewBox="0 0 100 100"` के साथ सही numbers हैं — line अब दिखती है।

## 10. भाषा toggle अब पूरे UI पर

पहले सिर्फ़ reading का content हिंदी होता था, बाकी buttons/headings English रहते थे।
अब `src/lib/i18n.js` में सारे UI शब्द EN+HI दोनों में हैं।
साथ ही: भाषा बदलने पर **चालू chat अब मिटती नहीं** (पहले मिट जाती थी)।

---

## जाँच जो चलाई गई

- `npm run build` — साफ़ build ✅
- `node scripts/test-functions.mjs` — 11 tests पास (नकली OpenRouter के साथ, key खर्च किए बिना) ✅
- असली browser में end-to-end: फोटो upload → reading → Guruji chat → भाषा बदलना →
  page reload के बाद history — सब चला, console में कोई error नहीं ✅
- Desktop और mobile दोनों layout देखे गए ✅
