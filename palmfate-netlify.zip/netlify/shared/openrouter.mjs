/**
 * OpenRouter helper — Base44 ke `core.InvokeLLM` / built-in AI ka replacement.
 *
 * Pehle AI call Base44 ki apni service se hoti thi. Ab yahan se seedha
 * OpenRouter ke OpenAI-compatible endpoint par jaati hai.
 * Key sirf server par rehti hai (Netlify env var), browser me kabhi nahi.
 */

const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
const DEFAULT_MODEL = 'google/gemini-2.5-flash';

export function getConfig() {
  const apiKey = process.env.OPENROUTER_API_KEY;
  return {
    apiKey,
    model: process.env.OPENROUTER_MODEL || DEFAULT_MODEL,
    siteUrl: process.env.OPENROUTER_SITE_URL || '',
    appName: process.env.OPENROUTER_APP_NAME || 'PalmFate'
  };
}

export function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store'
    }
  });
}

export async function readBody(req) {
  if (req.method !== 'POST') return { error: 'Only POST is allowed', status: 405 };
  try {
    const body = await req.json();
    if (!body || typeof body !== 'object') return { error: 'Invalid JSON body', status: 400 };
    return { body };
  } catch {
    return { error: 'Invalid JSON body', status: 400 };
  }
}

/** Image data-URL / https URL ki safety + size check */
export function validateImageUrl(url, { maxBytes = 4_500_000 } = {}) {
  if (typeof url !== 'string' || !url) return 'No image provided';
  if (url.startsWith('data:image/')) {
    // base64 length -> approx bytes
    const approxBytes = Math.floor((url.length - url.indexOf(',') - 1) * 0.75);
    if (approxBytes > maxBytes) return 'Image is too large. Please use a smaller photo.';
    return null;
  }
  if (/^https:\/\//i.test(url)) return null;
  return 'Unsupported image reference';
}

/**
 * OpenRouter chat completion.
 * @returns {Promise<{ text: string, model: string }>}
 */
export async function chatCompletion({
  messages,
  jsonMode = false,
  maxTokens = 1200,
  temperature = 0.8,
  timeoutMs = 25000
}) {
  const { apiKey, model, siteUrl, appName } = getConfig();
  if (!apiKey) {
    const err = new Error(
      'OPENROUTER_API_KEY set nahi hai. Netlify → Site configuration → Environment variables me add karein.'
    );
    err.code = 'NO_KEY';
    throw err;
  }

  const headers = {
    Authorization: `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
    'X-Title': appName
  };
  if (siteUrl) headers['HTTP-Referer'] = siteUrl;

  const payload = {
    model,
    messages,
    max_tokens: maxTokens,
    temperature
  };
  if (jsonMode) payload.response_format = { type: 'json_object' };

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  let res;
  try {
    res = await fetch(OPENROUTER_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
      signal: controller.signal
    });
  } catch (e) {
    clearTimeout(timer);
    const err = new Error(
      e.name === 'AbortError' ? 'AI ne jawab dene me bahut samay liya. Dobara koshish karein.' : e.message
    );
    err.code = 'NETWORK';
    throw err;
  }
  clearTimeout(timer);

  const raw = await res.text();
  if (!res.ok) {
    let detail = raw.slice(0, 400);
    try {
      detail = JSON.parse(raw)?.error?.message || detail;
    } catch { /* keep raw */ }
    const err = new Error(`OpenRouter error (${res.status}): ${detail}`);
    err.code = 'UPSTREAM';
    err.status = res.status === 401 ? 401 : 502;
    throw err;
  }

  let data;
  try {
    data = JSON.parse(raw);
  } catch {
    const err = new Error('OpenRouter se galat response mila.');
    err.code = 'BAD_RESPONSE';
    throw err;
  }

  const text = data?.choices?.[0]?.message?.content;
  if (typeof text !== 'string' || !text.trim()) {
    const err = new Error('AI ne khaali jawab diya. Dobara koshish karein.');
    err.code = 'EMPTY';
    throw err;
  }
  return { text, model: data.model || model };
}

/** Model kabhi-kabhi ```json fences ya extra text bhej deta hai — usse saaf karke parse karein */
export function parseJsonLoose(text) {
  const cleaned = String(text)
    .replace(/^﻿/, '')
    .replace(/```(?:json)?\s*/gi, '')
    .replace(/```/g, '')
    .trim();
  try {
    return JSON.parse(cleaned);
  } catch { /* try to locate the object */ }
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start !== -1 && end > start) {
    try {
      return JSON.parse(cleaned.slice(start, end + 1));
    } catch { /* fall through */ }
  }
  return null;
}
