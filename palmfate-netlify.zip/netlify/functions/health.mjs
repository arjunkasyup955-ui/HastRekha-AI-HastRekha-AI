/**
 * GET /api/health — jaanchne ke liye ki deploy theek hai ya nahi.
 * Key kabhi wapas nahi bhejta, sirf batata hai ki set hai ya nahi.
 */
import { getConfig, json } from '../shared/openrouter.mjs';

export default async () => {
  const { apiKey, model } = getConfig();
  return json({
    ok: true,
    functions: ['analyzePalm', 'chatWithPalmist', 'health'],
    openrouter_key_set: !!apiKey,
    model,
    time: new Date().toISOString()
  });
};
