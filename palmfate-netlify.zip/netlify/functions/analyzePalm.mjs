/**
 * POST /api/analyzePalm     body: { image_url }
 * ─────────────────────────────────────────────
 * Pehle ye Base44 ka backend function tha (base44.functions.invoke('analyzePalm')).
 * Ab ye Netlify Function hai jo OpenRouter ke vision model se hatheli padhta hai
 * aur wahi JSON shape wapas karta hai jo frontend pehle se expect karta hai:
 *   { reading: { summary, summary_hi, heart_line, ... love_rating, lucky_number } }
 */
import {
  chatCompletion,
  json,
  parseJsonLoose,
  readBody,
  validateImageUrl
} from '../shared/openrouter.mjs';

const SYSTEM_PROMPT = `You are Guruji AI — a warm, confident Indian palmist (hastrekha visheshagya) with decades of experience, writing a first reading for a new client.

You will be shown a photo of a person's hand. Read the four classic lines and produce a reading.

STYLE
- Confident and specific, never hedging or academic. Sound like India's most trusted phone astrologer.
- Each line reading: 2-3 sentences. Mention something that feels observed ("aapki hriday rekha gehri aur lambi hai...").
- Always mix one strength with one gentle caution, and end the summary with one concrete suggestion (a gemstone, a fasting day, or a mantra).
- NEVER predict death, terminal illness, or divorce. Soften hard things ("is samay thoda dhyaan rakhna hoga").
- This is entertainment; keep it hopeful and kind.

LANGUAGE
- English fields: warm Indian English.
- The *_hi fields: natural spoken HINDI in Devanagari script (not transliteration, not a literal word-by-word translation of the English).

OUTPUT
Return ONLY a JSON object, no markdown fences, no commentary, with exactly these keys:
{
  "is_palm": boolean,              // true only if the photo really shows a human hand/palm
  "summary": string,               // 3-4 sentences overall fortune (English)
  "summary_hi": string,            // same in Hindi (Devanagari)
  "overall_fortune": string,       // ONE word, e.g. "Auspicious", "Rising", "Blessed", "Turning Point"
  "overall_fortune_hi": string,    // ONE word in Hindi, e.g. "शुभ", "उन्नति", "सौभाग्य"
  "heart_line": string,            // emotions & relationships (English)
  "heart_line_hi": string,
  "life_line": string,             // vitality & energy
  "life_line_hi": string,
  "head_line": string,             // intellect & mind
  "head_line_hi": string,
  "destiny_line": string,          // fate & purpose
  "destiny_line_hi": string,
  "love_rating": number,           // 0-100
  "career_rating": number,         // 0-100
  "health_rating": number,         // 0-100
  "wealth_rating": number,         // 0-100
  "lucky_number": number           // 1-9
}
If the photo is not a hand, set "is_palm": false and keep the other fields as empty strings / zeros.`;

const clamp = (n, lo, hi, fallback) => {
  const v = Number(n);
  if (!Number.isFinite(v)) return fallback;
  return Math.min(hi, Math.max(lo, Math.round(v)));
};
const str = (v, fallback = '') => (typeof v === 'string' && v.trim() ? v.trim() : fallback);

export default async (req) => {
  const parsed = await readBody(req);
  if (parsed.error) return json({ error: parsed.error }, parsed.status);

  const imageUrl = parsed.body.image_url;
  const imageError = validateImageUrl(imageUrl);
  if (imageError) return json({ error: imageError }, 400);

  try {
    const { text } = await chatCompletion({
      jsonMode: true,
      maxTokens: 1600,
      temperature: 0.85,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'Please read this palm and return the JSON reading exactly as specified.'
            },
            { type: 'image_url', image_url: { url: imageUrl } }
          ]
        }
      ]
    });

    const data = parseJsonLoose(text);
    if (!data) {
      return json(
        { error: 'AI ka jawab samajh nahi aaya. Kripya dobara koshish karein.' },
        502
      );
    }

    if (data.is_palm === false) {
      return json(
        {
          error:
            'Ye photo hatheli ki nahi lag rahi. Kripya khuli hatheli ka saaf photo upload karein. (This does not look like a palm — please upload a clear photo of your open hand.)'
        },
        422
      );
    }

    // Frontend / purani PalmReading entity ke shape me normalize
    const reading = {
      summary: str(data.summary, 'The lines of your hand speak of a hopeful season ahead.'),
      summary_hi: str(data.summary_hi, str(data.summary)),
      overall_fortune: str(data.overall_fortune, 'Auspicious'),
      overall_fortune_hi: str(data.overall_fortune_hi, 'शुभ'),
      heart_line: str(data.heart_line),
      heart_line_hi: str(data.heart_line_hi, str(data.heart_line)),
      life_line: str(data.life_line),
      life_line_hi: str(data.life_line_hi, str(data.life_line)),
      head_line: str(data.head_line),
      head_line_hi: str(data.head_line_hi, str(data.head_line)),
      destiny_line: str(data.destiny_line),
      destiny_line_hi: str(data.destiny_line_hi, str(data.destiny_line)),
      love_rating: clamp(data.love_rating, 0, 100, 72),
      career_rating: clamp(data.career_rating, 0, 100, 78),
      health_rating: clamp(data.health_rating, 0, 100, 75),
      wealth_rating: clamp(data.wealth_rating, 0, 100, 70),
      lucky_number: clamp(data.lucky_number, 1, 99, 7)
    };

    return json({ reading });
  } catch (err) {
    const status = err.status || (err.code === 'NO_KEY' ? 500 : 502);
    return json({ error: err.message || 'Reading failed' }, status);
  }
};
