/**
 * POST /api/chatWithPalmist
 * body: { messages: [{role, content}], image_url?, reading_context?, lang? }
 * ─────────────────────────────────────────────────────────────────────────
 * Base44 function 'chatWithPalmist' ka replacement. Guruji ka skill prompt
 * netlify/shared/guruji-prompt.mjs se aata hai (wahan edit karein).
 * Response shape pehle jaisa: { reply }
 */
import { chatCompletion, json, readBody, validateImageUrl } from '../shared/openrouter.mjs';
import { buildGurujiSystemPrompt } from '../shared/guruji-prompt.mjs';

const MAX_TURNS = 16;          // history kitni bhejni hai
const MAX_CHARS = 2000;        // ek message me max characters

export default async (req) => {
  const parsed = await readBody(req);
  if (parsed.error) return json({ error: parsed.error }, parsed.status);

  const { messages, image_url: imageUrl, reading_context: readingContext, lang } = parsed.body;

  if (!Array.isArray(messages) || messages.length === 0) {
    return json({ error: 'No messages provided' }, 400);
  }

  // Sirf valid turns, saaf-suthre, aur last MAX_TURNS
  const history = messages
    .filter((m) => m && (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_CHARS) }))
    .slice(-MAX_TURNS);

  if (history.length === 0) return json({ error: 'No valid messages' }, 400);

  const imageOk = imageUrl && !validateImageUrl(imageUrl);
  const system = buildGurujiSystemPrompt({
    lang: lang === 'hi' ? 'hi' : 'en',
    readingContext: typeof readingContext === 'string' ? readingContext.slice(0, 3000) : '',
    hasImage: !!imageOk
  });

  // Hatheli ka photo sirf pehle user turn ke saath — har baar bhejna mehnga hai
  const outbound = [{ role: 'system', content: system }];
  let imageAttached = false;
  for (const m of history) {
    if (!imageAttached && imageOk && m.role === 'user') {
      outbound.push({
        role: 'user',
        content: [
          { type: 'text', text: m.content },
          { type: 'image_url', image_url: { url: imageUrl } }
        ]
      });
      imageAttached = true;
    } else {
      outbound.push(m);
    }
  }

  try {
    const { text } = await chatCompletion({
      messages: outbound,
      maxTokens: 700,
      temperature: 0.9
    });
    return json({ reply: text.trim() });
  } catch (err) {
    const status = err.status || (err.code === 'NO_KEY' ? 500 : 502);
    return json({ error: err.message || 'Chat failed' }, status);
  }
};
